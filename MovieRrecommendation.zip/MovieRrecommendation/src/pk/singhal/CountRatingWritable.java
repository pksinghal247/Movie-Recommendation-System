package pk.singhal;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import org.apache.hadoop.io.Writable;

public class CountRatingWritable implements Writable {
	private int count;
	private double rating;
	
	public CountRatingWritable() {
		this(0, 0.0);
	}	
	public CountRatingWritable(int count, double rating) {
		this.count = count;
		this.rating = rating;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public double getRating() {
		return rating;
	}
	public void setRating(double rating) {
		this.rating = rating;
	}
	
	@Override
	public void write(DataOutput out) throws IOException {
		out.writeInt(this.count);
		out.writeDouble(this.rating);
	}
	
	@Override
	public void readFields(DataInput in) throws IOException {
		this.count = in.readInt();
		this.rating = in.readDouble();
	}
	
	@Override
	public String toString() {
		return String.format("%d,%.1f", this.count, this.rating);
	}
}
