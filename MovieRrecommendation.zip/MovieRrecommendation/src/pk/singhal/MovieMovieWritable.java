package pk.singhal;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.WritableComparable;

public class MovieMovieWritable implements WritableComparable<MovieMovieWritable> {
	private int movie1;
	private int movie2;
	public MovieMovieWritable() {
	}
	public MovieMovieWritable(int movie1, int movie2) {
		this.movie1 = movie1;
		this.movie2 = movie2;
	}
	public int getMovie1() {
		return movie1;
	}
	public void setMovie1(int movie1) {
		this.movie1 = movie1;
	}
	public int getMovie2() {
		return movie2;
	}
	public void setMovie2(int movie2) {
		this.movie2 = movie2;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + movie1;
		result = prime * result + movie2;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof MovieMovieWritable))
			return false;
		MovieMovieWritable other = (MovieMovieWritable) obj;
		if (movie1 != other.movie1)
			return false;
		if (movie2 != other.movie2)
			return false;
		return true;
	}
	@Override
	public int compareTo(MovieMovieWritable other) {
		int diff = this.movie1 - other.movie1;
		if(diff == 0)
			diff = this.movie2 - other.movie2;
		return diff;
	}
	@Override
	public void write(DataOutput out) throws IOException {
		out.writeInt(this.movie1);
		out.writeInt(this.movie2);
	}
	@Override
	public void readFields(DataInput in) throws IOException {
		this.movie1 = in.readInt();
		this.movie2 = in.readInt();
	}
	@Override
	public String toString() {
		return String.format("%d,%d", this.movie1, this.movie2);
	}
}