package pk.singhal;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.Writable;

public class MovieRatingWritable implements Writable {
	private int movieId;
	private double rating;
	
	public MovieRatingWritable() {
		this(0, 0.0);
	}	
	public MovieRatingWritable(int movieId, double rating) {
		this.movieId = movieId;
		this.rating = rating;
	}
	public int getMovieId() {
		return movieId;
	}
	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}
	public double getRating() {
		return rating;
	}
	public void setRating(double rating) {
		this.rating = rating;
	}
	
	@Override
	public void write(DataOutput out) throws IOException {
		out.writeInt(this.movieId);
		out.writeDouble(this.rating);
	}
	
	@Override
	public void readFields(DataInput in) throws IOException {
		this.movieId = in.readInt();
		this.rating = in.readDouble();
	}
	
	@Override
	public String toString() {
		return String.format("%d,%.1f", this.movieId, this.rating);
	}
}
