package pk.singhal;

import java.util.Scanner;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.KeyValueTextInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
 
public class MovieRecommendationDriver extends Configured implements Tool {
	public static void main(String[] args) {
		try {
			// parse generic options
			GenericOptionsParser parser = new GenericOptionsParser(args);
			Configuration conf = parser.getConfiguration();
			
			// prepare & submit job
			MovieRecommendationDriver tool = new MovieRecommendationDriver();
			int exitCode = ToolRunner.run(conf, tool, args);
			System.exit(exitCode);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public int run(String[] args) throws Exception 
	{
		Scanner sc = new Scanner(System.in);
		if(args.length != 2) 
		{
			args = new String[2];
			System.out.print("Enter Input Path	:	");
			args[0] = sc.nextLine();
			System.out.print("Enter Output Path	:	");
			args[1] = sc.nextLine();
		}
		
		// create job = mapper + reducer
		Configuration conf = this.getConf();
		Job userMoviesJob = Job.getInstance(conf, "UserMovies");
		userMoviesJob.setJarByClass(MovieRecommendationDriver.class);
		
		userMoviesJob.setMapperClass(UserMovieMapper.class);
		userMoviesJob.setMapOutputKeyClass(IntWritable.class);
		userMoviesJob.setMapOutputValueClass(MovieRatingWritable.class);
		
		userMoviesJob.setReducerClass(UserMovieReducer.class);
		userMoviesJob.setOutputKeyClass(IntWritable.class);
		userMoviesJob.setOutputValueClass(Text.class);
		
		TextInputFormat.setInputPaths(userMoviesJob, new Path(args[0]));
		TextOutputFormat.setOutputPath(userMoviesJob, new Path("/tmp/usermovies"));
		
		// submit to cluster
		userMoviesJob.submit();
		boolean success = userMoviesJob.waitForCompletion(true);
		if(success) {
			Job corrJob = Job.getInstance(conf, "CorrJob");
			corrJob.setJarByClass(MovieRecommendationDriver.class);
			
			corrJob.setMapperClass(MovieSimilarityMapper.class);
			corrJob.setMapOutputKeyClass(MovieMovieWritable.class);
			corrJob.setMapOutputValueClass(RatingRatingWritable.class);
			
			corrJob.setReducerClass(MovieSimilarityReducer.class);
			corrJob.setOutputKeyClass(MovieMovieWritable.class);
			corrJob.setOutputValueClass(CountRatingWritable.class);
			
			corrJob.setInputFormatClass(KeyValueTextInputFormat.class);
			
			FileInputFormat.setInputPaths(corrJob, new Path("/tmp/usermovies"));
			FileOutputFormat.setOutputPath(corrJob, new Path(args[1]));
			
			// submit to cluster
			corrJob.submit();
			success = corrJob.waitForCompletion(true);
		} sc.close();
		int exitCode = success ? 0 : 1;		
		return exitCode;
	}
}
