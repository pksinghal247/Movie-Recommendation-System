package pk.singhal;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MovieSimilarityMapper extends Mapper<Text, Text, MovieMovieWritable, RatingRatingWritable> {
	private MovieMovieWritable movieMovieWr = new MovieMovieWritable();
	private RatingRatingWritable ratingRatingWr = new RatingRatingWritable();
	@Override
	protected void map(Text key, Text value, Mapper<Text, Text, MovieMovieWritable, RatingRatingWritable>.Context ctx)
			throws IOException, InterruptedException {
		String line = value.toString();
		String[] parts = line.split(",");
		MovieRatingWritable[] arr = new MovieRatingWritable[parts.length/2];
		for(int i=0; i<parts.length; i+=2) {
			int j = i / 2;
			int movie = Integer.parseInt(parts[i]);
			double rating = Double.parseDouble(parts[i+1]);
			arr[j] = new MovieRatingWritable(movie, rating);
		}
		for(int i=0; i<arr.length; i++) {
			for(int j=i+1; j<arr.length; j++) {
				int m1 = arr[i].getMovieId(), m2 = arr[j].getMovieId();
				double r1 = arr[i].getRating(), r2 = arr[j].getRating();
				if(m1 > m2) {
					int tm = m1; m1 = m2; m2 = tm;
					double tr = r1; r1 = r2; r2 = tr;
				}
				movieMovieWr.setMovie1(m1);
				movieMovieWr.setMovie2(m2);
				ratingRatingWr.setRating1(r1);
				ratingRatingWr.setRating2(r2);
				ctx.write(movieMovieWr, ratingRatingWr);
			}
		}
	}
}
