package pk.singhal;

import java.io.IOException;

import org.apache.hadoop.mapreduce.Reducer;

public class MovieSimilarityReducer extends Reducer<MovieMovieWritable, RatingRatingWritable, MovieMovieWritable, CountRatingWritable> {
	@Override
	protected void reduce(MovieMovieWritable key, Iterable<RatingRatingWritable> values,
			Reducer<MovieMovieWritable, RatingRatingWritable, MovieMovieWritable, CountRatingWritable>.Context ctx)
			throws IOException, InterruptedException {
		int cnt = 0;
		double sumX = 0.0, sumY = 0.0, sumXY = 0.0, sumXX = 0.0, sumYY = 00;
		for (RatingRatingWritable ratingRatingWritable : values) {
			double x = ratingRatingWritable.getRating1();
			double y = ratingRatingWritable.getRating2();
			cnt++;
			sumX += x;
			sumY += y;
			sumXY += x * y;
			sumXX += x * x;
			sumYY += y * y;
		}
		if(cnt > 1) {
			double corr = (cnt * sumXY - sumX * sumY) / Math.sqrt( (cnt * sumXX - sumX * sumX) * (cnt * sumYY - sumY * sumY) ); 
			if(!Double.isNaN(corr)) {
				CountRatingWritable countRatingWr = new CountRatingWritable(cnt, corr);
				ctx.write(key, countRatingWr);
			}
		}
	}
}






