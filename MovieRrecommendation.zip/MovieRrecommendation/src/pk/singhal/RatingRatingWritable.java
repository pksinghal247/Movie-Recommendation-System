package pk.singhal;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.Writable;

public class RatingRatingWritable implements Writable {
	private double rating1;
	private double rating2;
	public RatingRatingWritable() {
	}
	public RatingRatingWritable(double rating1, double rating2) {
		this.rating1 = rating1;
		this.rating2 = rating2;
	}
	public double getRating1() {
		return rating1;
	}
	public void setRating1(double rating1) {
		this.rating1 = rating1;
	}
	public double getRating2() {
		return rating2;
	}
	public void setRating2(double rating2) {
		this.rating2 = rating2;
	}
	@Override
	public void write(DataOutput out) throws IOException {
		out.writeDouble(this.rating1);
		out.writeDouble(this.rating2);
	}
	@Override
	public void readFields(DataInput in) throws IOException {
		this.rating1 = in.readDouble();
		this.rating2 = in.readDouble();
	}
	@Override
	public String toString() {
		return String.format("%.1f,%.1f", rating1, rating2);
	}
}

