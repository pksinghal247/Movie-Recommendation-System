package pk.singhal;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class UserMovieReducer extends Reducer<IntWritable, MovieRatingWritable, IntWritable, Text> {
	private Text movieRatingsText = new Text();
	@Override
	protected void reduce(IntWritable userIdKey, Iterable<MovieRatingWritable> values,
			Reducer<IntWritable, MovieRatingWritable, IntWritable, Text>.Context ctx) throws IOException, InterruptedException {
		StringBuilder sb = new StringBuilder();
		for (MovieRatingWritable movieRatingWr: values) {
			sb.append(movieRatingWr.toString());
			sb.append(",");
		}
		sb.deleteCharAt(sb.length()-1);
		movieRatingsText.set(sb.toString());	
		ctx.write(userIdKey, movieRatingsText);
	}
}






